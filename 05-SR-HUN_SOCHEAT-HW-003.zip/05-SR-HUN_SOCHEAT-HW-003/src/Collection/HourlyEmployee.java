package Collection;

public class HourlyEmployee extends StaffMember {

    private int hour;
    private String xxx;

    public HourlyEmployee(int id, String name, String address, int hour, String xxx) {
        super(id, name, address);
        this.hour = hour;
        this.xxx = xxx;
    }

    @Override
    public double pay() {
        return 0;
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public String getXxx() {
        return xxx;
    }

    public void setXxx(String xxx) {
        this.xxx = xxx;
    }

    @Override
    public String toString() {
        return "HourlyEmployee{" +
                "hour=" + hour +
                ", xxx='" + xxx + '\'' +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", Address='" + Address + '\'' +
                '}';
    }
}
