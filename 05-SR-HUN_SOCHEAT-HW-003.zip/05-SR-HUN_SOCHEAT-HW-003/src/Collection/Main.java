package Collection;

import java.util.*;
public class Main {
    ArrayList<HourlyEmployee> Hour= new ArrayList<HourlyEmployee>();
    Hour



    int choose,ch;

    public void De_display() {

    }
    public void menu(){
        Scanner sc = new Scanner(System.in);
        System.out.println("1./ Add Employee   2./ Edit   3./ Remove   4./ Exit");
        System.out.println("Please Enter Number : ");
        choose = sc.nextInt();
        switch (choose){
            case 1:
                System.out.println("1./ Volunteer  2./ Hourly Emp  3./ Salaried Emp  4./ Back");
                System.out.println("Enter choose : ");
                ch=sc.nextInt();
                switch (ch){
                    case 1:
                        System.out.println("ID :");
                        System.out.println("Name : ");
                        System.out.println("Address :");
                        System.out.println("Thank!");
                }
            case 2:
            case 3:
            case 4:
                System.exit(0);
                break;
        }
    }
    public static void main(String[] args) {
        Main emp = new Main();
        emp.De_display();
        emp.menu();
    }
}
