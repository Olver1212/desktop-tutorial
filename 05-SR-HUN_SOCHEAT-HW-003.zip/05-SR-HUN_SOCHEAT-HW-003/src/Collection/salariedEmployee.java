package Collection;

public class salariedEmployee extends StaffMember{
    private double salary;
    private double bonus;

    public salariedEmployee(int id, String name, String address) {
        super(id, name, address);
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public String toString() {
        return "salariedEmployee{" +
                "salary=" + salary +
                ", bonus=" + bonus +
                '}';
    }

    @Override
    public double pay() {
        return 0;
    }
}
